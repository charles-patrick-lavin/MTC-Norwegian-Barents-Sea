# Script for:
# Fisheries catch and research data show increased abundance of
# warm-water fishes in the Norwegian and Barents Sea in line with ocean warming

# Marine Ecology Progress Series

# Authors: 
# Charles P. Lavin, Faculty of Biosciences and Aquaculture, Nord University, Bodø, Norway.
# ORCID: 0000-0002-2068-1080

# Daniel Pauly, Sea Around Us, Institute for the Ocean and Fisheries, University of British Columbia, Vancouver, British # Columbia, Canada.
# ORCID: 0000-0003-3756-4793

# Cesc Gordó-Vilaseca, Faculty of Biosciences and Aquaculture, Nord University, Bodø, Norway.
# ORCID: 0000-0001-5992-218X

# Mark Costello, Faculty of Biosciences and Aquaculture, Nord University, Bodø, Norway.
# ORCID: 0000-0003-2362-0328

# Donna Dimarchopoulou, Department of Biology, Dalhousie University, Halifax, Nova Scotia, Canada; Department of Biology, # Woods Hole Oceanographic Institution, Woods Hole, Massachusetts, USA.
# ORCID: 0000-0003-3412-3503

# Fisheries data extracted for the Norwegian Sea and Barents Sea Large Marine Ecosystems (LMEs)
# from the Sea Around Us: https://www.seaaroundus.org/
# Citation: Pauly D, Zeller D, Palomares MLD (2020) Sea Around Us. Concepts, design and data (seaaroundus.org). http://www.seaaroundus.org/data/#/spatial-catch

# Trawl survey data provided by Norway's Institute of Marine Research, and accessed via the Norwegian
# Marine Data Centre(http://metadata.nmdc.no/metadata-api/landingpage/f77112db062b5924d079a54b311260fb)
# Citation: Djupevåg O (2021) IMR bottom trawl data 1980-2020. https://doi.org/10.21335/NMDC-328259372

library(tidyverse)
library(dplyr)
library(plyr)
library(data.table)
library(tibble)
library(rfishbase)
library(corrplot)
library(Hmisc)
library(car)
library(segmented)
library(FactoMineR)
library(factoextra)
library(rstatix)
library(broom)
library(emmeans)
library(ggplot2)
library(ggpubr)
library(ggpmisc)
library(rstudioapi)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()


# Loading in sea surface temperature anomaly (SSTA) data for the trawl survey area
# Extracted from NOAA’s Kaplan Extended SST V2 database (https://psl.noaa.gov/data/gridded/data.kaplan_sst.html)
ssta_trawl <- read.csv("ssta_1950_2020_trawl_area.csv")

# Loading in SSTA data for Norwegian and Barents Sea LMEs
ssta_lme <- read.csv("ssta_1950_2018_LMEs.csv")

# Loading in oceanographic indicators for the study area
# Extracted from NOAA’s GCOS-WGSP database (https://psl.noaa.gov/gcos_wgsp/Timeseries/)
oceano <- read.csv("Norway_OI.csv")


# Loading in Sea Around Us catch data for the Norwegian and Barents Sea LMEs 
SAU_data <- read.csv("Sea_Around_Us_Norwegian_Barents_Sea.csv")


# rfishbase package to extract mean temperature preferences for species
SAU_FB <- rfishbase::estimate(species_list = unique(SAU_data$scientific_name))

SAU_temp <- SAU_FB[,(c(2,43))] #selecting spp and TempPrefMean
SAU_temp$Species <- as.factor( paste0( as.factor( SAU_temp$Species )))
str(SAU_temp)
SAU_temp <- SAU_temp %>% drop_na() %>% distinct()
list(unique(SAU_temp)) # 72 spp
names(SAU_temp) <- c("scientific_name", "mean_temp")

#Join SAU data with SAU temp
SAU_data <- inner_join(SAU_data, SAU_temp, by="scientific_name")
list(unique(SAU_data$scientific_name))



# calculating annual catch per species
SAU_catch <- SAU_data %>%
  dplyr::group_by(year, scientific_name) %>%
  dplyr::summarise(Annual_catch = sum(tonnes)) %>%
  dplyr::mutate(log_catch = log(Annual_catch))

names(SAU_catch) <- c("Year", "scientific_name", "catch", "log_catch")
SAU_catch <- SAU_catch %>% filter(catch > 0)
SAU_catch$Year <- as.numeric(as.character(SAU_catch$Year))

list(unique(SAU_catch$scientific_name))
str(SAU_catch)

# Catch figure
# Grouping total  by key groups, to
# display composition of species
SAU_catch$scientific_name <- as.factor(SAU_catch$scientific_name)

SAU_proportion = SAU_catch %>%
  mutate(Group = case_when(scientific_name == "Clupea harengus" ~ 'Atlantic herring',
                           scientific_name == "Gadus morhua" ~ 'Atlantic cod',
                           scientific_name == "Mallotus villosus" ~ 'Capelin',
                           scientific_name == "Pollachius virens" ~ 'Saithe',
                           scientific_name == "Scomber scombrus" ~ 'Atlantic mackerel',
                           scientific_name == "Melanogrammus aeglefinus" ~ 'Haddock',
                           scientific_name == "Micromesistius poutassou" ~ 'Blue whiting',
                           scientific_name == "Micromesistius poutassou" ~ 'Blue whiting')) %>%
  drop_na()



# 'Other' landings group
remove = c("Clupea harengus", "Gadus morhua", "Mallotus villosus", "Pollachius virens", "Scomber scombrus", "Melanogrammus aeglefinus", "Micromesistius poutassou")

final_remove = SAU_catch %>% filter(!scientific_name %in% remove) %>%
  mutate(Group = "Other")

SAU_proportion <- rbind(SAU_proportion, final_remove)

SAU_proportion$Group <- as.factor(SAU_proportion$Group)
str(SAU_proportion)


SAU_final_catch = SAU_proportion %>%
  dplyr::group_by(Year, Group) %>%
  dplyr::summarise(Catch = sum(catch))


SAU_final_catch$Year = as.numeric(as.character(SAU_final_catch$Year ))
SAU_final_catch$Catch = as.numeric(as.character(SAU_final_catch$Catch ))

# replacing NAs with 0
SAU_final_catch[is.na(SAU_final_catch)] = 0

SAU_final_catch <- SAU_final_catch %>%
  mutate(Catch = Catch*0.000001)

Fig_2 = ggplot(data=SAU_final_catch, aes(x=Year, y=Catch, fill=Group)) + geom_area(stat="identity") +
  labs(y = Catch~(tonnes~x~10^6), x = "Year") +
  theme_classic() +
  scale_x_continuous(breaks = seq(1950, 2020, by = 10)) +
  scale_y_continuous(limits = c(0, 5), expand = c(0, 0)) +
  labs(fill = "Group") +
  theme(axis.text = element_text(colour = "black")) +
  scale_fill_brewer(palette="Set3") +
  theme(axis.title.y = element_text(size=24)) +
  theme(axis.title.x = element_text(size=24)) +
  theme(axis.text.y = element_text(size=20)) +
  theme(axis.text.x = element_text(size=20)) +
  theme(legend.title=element_text(size=16)) +
  theme(legend.text=element_text(size=14)) +
  theme(plot.margin = margin(0, 1, 0, 0.5,"cm")) +
  theme(legend.position = c(0.8, 0.9)) +
  guides(fill=guide_legend(ncol=2)) +
  theme(plot.margin = margin(0.5, 0.5, 0, 0,"cm"))

Fig_2


# Spp per year
sau_spp <- SAU_catch %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(spp = n_distinct(scientific_name))
sau_spp$Year <- as.numeric(as.character(sau_spp$Year))

formula <- y ~ x

Supp_Fig_4a <- ggplot(data=sau_spp, aes(x=Year, y=spp)) +
  geom_smooth(method = "lm", se = TRUE, col="red") +
  stat_poly_eq(aes(label = paste(..eq.label.., ..rr.label.., sep = "~~~")), 
               label.x.npc = "right", label.y.npc = 0.8,
               formula = formula, parse = TRUE, size = 8) +
  geom_line(size=1) +
  theme_classic() +
  ylab("# of species recorded") +
  xlab("Year") +
  scale_x_continuous(breaks = seq(1950, 2020, 10)) +
  scale_y_continuous(breaks = seq(30, 110, 10), limits = c(27,110)) +
  theme(axis.text.x = element_text(size=22),
        axis.text.y = element_text(size=26),
        axis.title.x = element_blank(),
        axis.title.y = element_text(size=26),
        plot.margin = margin(0, 0.5, 0.1, 0,"cm"))


Supp_Fig_4a


# Calculating Sea Around Us MTC
SAU_mtc <- inner_join(SAU_catch, SAU_temp, by="scientific_name")

summary(SAU_mtc) #no NAs
str(SAU_mtc)
list(unique(SAU_mtc$scientific_name)) #72 spp w/ available temperature preference
# 99.82403 % of total catch (after removing 14 spp. w/out available temperature preferences)

#check temp outliers
boxplot(SAU_mtc$mean_temp)
sort( unique( SAU_mtc$mean_temp ) )

#calculating MTC
SAU_mtc_temp <- SAU_mtc %>%
  dplyr::group_by(Year) %>%
  dplyr::mutate(numerator = catch*mean_temp)

SAU_mtc_num <- SAU_mtc_temp %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(num = sum(numerator))

SAU_mtc_den <- SAU_mtc %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(den = sum(catch))

SAU_mtc_final <- cbind(SAU_mtc_num$num,SAU_mtc_den$den)
SAU_mtc_final <- as.data.frame(SAU_mtc_final)
names(SAU_mtc_final) <- c("numerator", "denominator")

SAU_mtc_final <- SAU_mtc_final %>%
  mutate(final = numerator/denominator)

SAU_years <- as_tibble(unique(SAU_mtc$Year))
SAU_mtc_value <- as_tibble(SAU_mtc_final$final)

SAU_Norway_mtc <- cbind(SAU_years,SAU_mtc_value)
names(SAU_Norway_mtc) <- c("Year", "MTC")
SAU_Norway_mtc$Year <- as.numeric(as.character(SAU_Norway_mtc$Year))
str(SAU_Norway_mtc)

# Simple linear regression of fisheries MTC and Year
SAU_MTC_year <- lm(MTC ~ Year, data=SAU_Norway_mtc)
summary(SAU_MTC_year)
# no significant trend in SAU MTC

# Segmented regression of fisheries MTC and Year
sau.seg <- segmented(SAU_MTC_year, #SAU_MTC_year = lm(MTC ~ Year, data=SAU_Norway_mtc)
                     seg.Z = ~ Year,
                     psi = list(Year = c(1978)))

summary.segmented(sau.seg)

# get breakpoints
sau.seg$psi # breakpoint in 1978
# get the slopes
slope(sau.seg)

# get the fitted data
seg.fitted <- fitted(sau.seg)
seg.model <- data.frame(Year = SAU_Norway_mtc$Year, MTC = seg.fitted)

# plot segmented regression slopes
ggplot(seg.model, aes(x= Year, y= MTC)) + geom_line() + theme_classic() +
  scale_y_continuous(breaks = seq(4, 8, by = 1), limits = c(3.5,8)) +
  scale_x_continuous(breaks = seq(1950, 2020, by = 10), limits = c(1950,2020))

pscore.test(sau.seg) # p-score test for non-zero difference in slope parameters 

#adding SSTA and oceanographic indicators to Sea Around Us MTC data, 1950-2018
SAU_Norway_mtc <- cbind(SAU_Norway_mtc, ssta_lme[1:69,2], oceano[1:69,2:4])
names(SAU_Norway_mtc) <- c("Year", "MTC", "SSTA", "AMO", "NAO", "AO")
SAU_Norway_mtc

# checking collinearity of variables
matrix_1 <- rcorr( as.matrix( SAU_Norway_mtc[,c("MTC", "SSTA", "AMO", "NAO", "AO")], type = "pearson" ) )
corrplot( matrix_1$r, type = "lower", tl.col = "black", method = "number", title = "SAU Norway MTC", 
          mar = c( 0, 0, 1, 0 ), p.mat = matrix_1$P, sig.level = 0.05)


# Segmented regression of SSTA across fisheries study area
SAU_SSTA_year <- lm(SSTA ~ Year, data=SAU_Norway_mtc)
summary(SAU_SSTA_year)

# segmented regression
sau.ssta <- segmented(SAU_SSTA_year,
                      seg.Z = ~ Year,
                      psi = list(Year = c(1981)))
summary(sau.ssta)

# get the breakpoint
sau.ssta$psi # Breakpoint in 1981
# get the slopes
slope(sau.ssta)

# get the fitted data of segmented slope (for figure)
seg.fitted.1 <- fitted(sau.ssta)
seg.model.1 <- data.frame(Year = SAU_Norway_mtc$Year, SSTA = seg.fitted.1)

# plot fitted model
ggplot(seg.model.1, aes(x= Year, y= SSTA)) + geom_line() + theme_classic()

pscore.test(sau.ssta) # p-score test for non-zero difference in slope parameters


# Multiple linear regression of fisheries catch data and SSTA, oceanographic indicators
# Fisheries MTC restricted to 1978-2018 
SAU_Norway_rest <- SAU_Norway_mtc[29:69,]

matrix_1 <- rcorr( as.matrix( SAU_Norway_rest[,c("MTC", "SSTA", "AMO", "NAO", "AO")], type = "pearson" ) )
corrplot( matrix_1$r, type = "lower", tl.col = "black", method = "number", title = "SAU Norway Restricted", 
          mar = c( 0, 0, 1, 0 ), p.mat = matrix_1$P, sig.level = 0.05)
#SSTA & AMO collinear, NAO & AO collinear
# We retain SSTA and NAO

SAU_Norway_rest <- SAU_Norway_rest[,c(1,2,3,5)] #removing AMO & AO

SAU_multi <- lm(MTC ~ SSTA+NAO, data = SAU_Norway_rest) #note: R uses Type III SS as default
summary(SAU_multi)

#Model evaluation

#1) Residuals
residualPlots(SAU_multi)

#2) Testing non-constant variance
ncvTest(SAU_multi) # p=0.009, non-constant variance detected

#3) Shapiro-Wilkes test
shapiro.test(residuals(SAU_multi))

#4) Variance inflation factors
vif(SAU_multi)

#5) Outlier test
outlierTest(SAU_multi)
outl<-as.numeric(names(which(outlierTest(SAU_multi)$bonf.p<0.05)))
outl

# All assumptions met, except non-constant variance (NAO)
# Using white correction for non-constant variance
Anova(SAU_multi, white.adjust=TRUE)


# Principal component analysis (singular value decomposition, SVD), with SAU MTC
# and all oceanographic variables (centred)

PCA_sau <- SAU_Norway_mtc[29:69,1:6]

sau.pca <- PCA(PCA_sau, scale.unit = TRUE, ncp=6, graph=TRUE)              
print(sau.pca)
eig.val <- get_eigenvalue(sau.pca)
eig.val

#scree plot to visually inspect PC's eigenvalues
fviz_eig(sau.pca, addlabels = TRUE, ylim = c(0,60))

var <- get_pca_var(sau.pca)
var

# access components
# Coordinates
head(var$coord)
# Cos2: quality on the factor map
head(var$cos2)
# Contributions to the principal components
head(var$contrib)
# plot variables
fviz_pca_var(sau.pca, col.var="black", label = "var")

# extract pc scores for first two component and add to dat dataframe

PCA_sau$pc1 = sau.pca$ind$coord[, 1] # indexing the first carctic
PCA_sau$pc2 = sau.pca$ind$coord[, 2]  # indexing the second column

#extract the data for the variable contributions to each of the pc axes.
pca.vars <- sau.pca$var$coord %>% data.frame
pca.vars$vars <- rownames(pca.vars)
pca.vars.m <- melt(pca.vars, id.vars = "vars")

# function to create PCA circle
circleFun <- function(center = c(0,0),diameter = 1, npoints = 100){
  r = diameter / 2
  tt <- seq(0,2*pi,length.out = npoints)
  xx <- center[1] + r * cos(tt)
  yy <- center[2] + r * sin(tt)
  return(data.frame(x = xx, y = yy))
}

circ <- circleFun(c(0,0),2,npoints = 500)

# Fisheries catch PCA plot
Supp_Fig_3a = ggplot() + geom_path(data = circ,aes(x,y), lty = 2, color = "grey", alpha = 0.7) +
  geom_hline(yintercept = 0, lty = 2, color = "grey", alpha = 0.9) +
  geom_vline(xintercept = 0, lty = 2, color = "grey", alpha = 0.9) +
  geom_segment(data = pca.vars, aes(x = 0, xend = Dim.1, y = 0, yend = Dim.2),
               arrow = arrow(length = unit(0.025, "npc"), type = "open"), lwd = 1) +
  geom_text(data = pca.vars, aes(x = Dim.1*1.1, y =  Dim.2*0.9,
                                 label = c("Year", "MTC","SSTA","AMO","NAO","AO")),check_overlap = F,size = 3) +
  xlab("PC 1") + 
  ylab("PC2") +
  coord_equal() +
  theme_minimal() +
  theme(panel.grid = element_blank(), 
        panel.border = element_rect(fill= "transparent"))

Supp_Fig_3a

# Plot of SAU MTC and SSTA (second axis)
Fig_3a <- ggplot(data=SAU_Norway_mtc, aes(x=Year)) +
  geom_point(aes(y=MTC), cex=2.5, col="red") +
  geom_path(aes(y=MTC), cex=1, col="red") +
  geom_bar(aes(y=SSTA*10), stat="identity", size=.25, color="black", alpha=.4) +
  scale_y_continuous(
    name= "MTC (°C)",
    sec.axis = sec_axis(~./10, name = "SSTA (°C)")
  ) +
  theme_classic() +
  ylab("MTC (°C)") +
  xlab("Year") +
  scale_x_continuous(breaks = seq(1950,2020,10), limits = c(1950,2020)) +
  theme(axis.text.x = element_text(size=24),
        axis.text.y = element_text(size=24),
        axis.title.x = element_blank(),
        axis.title.y = element_blank()) +
  geom_line(data=seg.model, aes(x= Year, y= MTC), cex=1.3, col="black") +
  geom_vline(xintercept=c(1978), linetype="longdash", size=0.85, col="black")

Fig_3a

# Investigating the influence of individual species on the MTC trend, 
# through their slope of abundance (catch) and maximum catch value

# Changes in slope of caught species
require(data.table)
dt <- data.table(SAU_catch)
dt <- na.omit(dt)

# calculating slope of catch
slopes <- dt[,list(slope=lm(log_catch~Year)$coef),by=scientific_name]

dat1 <- SAU_catch

get.coef <- function(dat1) lm(log_catch ~ Year, dat1)$coefficients

summary(lm(log_catch ~ Year, dat1))

lm_results1 <- as.data.frame(ddply(dat1, .(scientific_name), get.coef))
sum(is.na(lm_results1))

max1 <- SAU_catch %>%
  dplyr::group_by(scientific_name) %>%
  dplyr::summarise(mean = mean(catch))

max1$mean <- max1$mean %>% format(scientific=FALSE)

# here we have species, lm intercept and slope (Year), as well as mean catch
lm_max1 <- inner_join(lm_results1, max1, by = "scientific_name")

# add spp mean temperature preference
lm_max1 <- inner_join(lm_max1, SAU_temp, by = "scientific_name")

lm_max1 <- lm_max1 %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  )) %>%
  mutate(slope_change = case_when(
    Year > 0 ~ "Positive",
    Year < 0 ~ "Negative"
  ))



# Example, removing Capelin from SAU catch
sau_rerun <- droplevels(SAU_mtc[!SAU_mtc$scientific_name == 'Mallotus villosus',])
str(sau_rerun)


sau_rerun <- inner_join(sau_rerun, SAU_temp, by="scientific_name")
sau_rerun$scientific_name <- as.factor( paste0( as.factor( sau_rerun$scientific_name )))
summary(sau_rerun) #no NAs
str(sau_rerun)

# 'Remove' MTC
sau_rerun_temp <- sau_rerun %>%
  dplyr::group_by(Year) %>%
  dplyr::mutate(numerator = catch*mean_temp.x)

sau_rerun_num <- sau_rerun_temp %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(num = sum(numerator))

sau_rerun_den <- sau_rerun %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(den = sum(catch))

sau_rerun_numer <- as_tibble(sau_rerun_num$num)
sau_rerun_denom <- as_tibble(sau_rerun_den$den)

sau_rerun_final <- cbind(sau_rerun_numer,sau_rerun_denom)
names(sau_rerun_final) <- c("numerator", "denominator")

sau_rerun_final <- sau_rerun_final %>%
  mutate(final = numerator/denominator)

years <- as_tibble(unique(SAU_mtc$Year))
sau_rerun_value <- as_tibble(sau_rerun_final$final)

sau_mtc_rerun <- cbind(years,sau_rerun_value)
names(sau_mtc_rerun) <- c("Year", "MTC")

sau_mtc_rerun$Year <- as.numeric(as.character(sau_mtc_rerun$Year))
str(sau_mtc_rerun)

sau_rerun_slope <- lm(MTC ~ Year, data=sau_mtc_rerun)
summary(sau_rerun_slope)

# No species cause large change in fisheries catch MTC with their removal



# Loading in IMR trawl survey data (data already treated and filtered, see methods)
data <- read.csv("IMR_trawl_survey_filtered_Lavin_et_al_2023.csv") 
summary(data) #data is from 1994-2020
data$valid_name <- as.factor(data$valid_name)
str(data$valid_name)

spp_count <- data %>% dplyr::group_by(valid_name, Year) %>% tally()

species_arctic <- unique(data$valid_name)

# Trawl survey species list into rfishbase estimate function
fish_arctic <- rfishbase::estimate(species_list = species_arctic)
summary(fish_arctic)

temp_arctic <- fish_arctic[,(c(2,43))] #selecting spp and TempPrefMean
temp_arctic$Species <- as.factor( paste0( as.factor( temp_arctic$Species )))
str(temp_arctic) # 161 spp
temp_arctic <- temp_arctic %>% drop_na() %>% distinct()
temp_arctic$Species <- as.factor( paste0( as.factor( temp_arctic$Species )))
str(temp_arctic)
unique(temp_arctic$Species)
nrow(temp_arctic) #152 spp
names(temp_arctic) <- c("scientific_name", "mean_temp")
str(temp_arctic)

str(unique(data$Coordinates)) #17514 trawls
summary(data$Bot_depth)

str(data$Year)
data$Year <- as.factor( paste0( as.factor( data$Year )))
#calculating relative abundance
data <- data %>% mutate(swept_area_km2 = swept_area / 1000000)
data <- data %>% mutate(relative_abundance = Total_abund/swept_area_km2)


# Summarising relative abundance (and log relative abundance) of species per year
total_arctic <- data %>%
  dplyr::group_by(Year, valid_name) %>%
  dplyr::summarise(relative_annual_abundance = sum(relative_abundance))

names(total_arctic) <- c("Year", "scientific_name", "relative_abundance")
list(unique(total_arctic$scientific_name)) #161 spp
str(total_arctic)

total_arctic <- total_arctic %>% mutate(log_abundance = log(relative_abundance))
summary(total_arctic)

# scientific name as factor
total_arctic$scientific_name <- as.factor( paste0( as.factor( total_arctic$scientific_name  )))
str(total_arctic)
class(total_arctic$scientific_name)

# year as numeric
total_arctic$Year <- as.numeric( paste0( as.character( total_arctic$Year  )))
class(total_arctic$Year)

# log abundance as numeric
total_arctic$log_abundance <- as.numeric( paste0( as.character( total_arctic$log_abundance  )))
class(total_arctic$log_abundance)

# Spp per year
arctic_spp <- total_arctic %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(spp = n_distinct(scientific_name))
arctic_spp$Year <- as.numeric(as.character(arctic_spp$Year))

# trawls per year
trawls <- data[!duplicated(data$Coordinates), ]
trawls <- trawls %>%
  dplyr::group_by(Year) %>%
  tally()
trawls$Year <- as.numeric(as.character(trawls$Year))

# Figure
Supp_Fig_4b <- ggplot(data=arctic_spp, aes(x=Year, y=spp)) +
  geom_smooth(method = "lm", se = TRUE, col="red") +
  stat_poly_eq(aes(label = paste(..eq.label.., ..rr.label.., sep = "~~~")), 
               label.x.npc = "right", label.y.npc = 0.2,
               formula = formula, parse = TRUE, size = 8) +
  geom_line(size=1) +
  theme_classic() +
  xlab("Year") +
  scale_x_continuous(breaks = seq(1950, 2020, 10), limits = c(1950,2020)) +
  scale_y_continuous(breaks = seq(30, 110, 10), limits = c(27,110)) +
  theme(axis.text.x = element_text(size=22),
        axis.text.y = element_text(size=26),
        axis.title.x = element_blank(),
        axis.title.y = element_blank())

Supp_Fig_4b

# Supplementary Fig. 4, # of species recorded in each dataset by year
Supp_Fig_4 = ggarrange(Supp_Fig_4a, Supp_Fig_4b, align = c("v"), ncol = 2, nrow=1,labels = c("a Fisheries catch", "b Research data"), font.label = list(size = 24, face = "plain"), hjust=-0.6)

Supp_Fig_4


# Calculating MTC from trawl survey data
arctic_mtc <- inner_join(total_arctic, temp_arctic, by="scientific_name")
arctic_mtc$scientific_name <- as.factor( paste0( as.factor( arctic_mtc$scientific_name )))
str(arctic_mtc) # 152 species with available temp pref data
summary(arctic_mtc)

arctic_mtc_temp <- arctic_mtc %>%
  dplyr::group_by(Year) %>%
  dplyr::mutate(numerator = relative_abundance*mean_temp)

arctic_mtc_num <- arctic_mtc_temp %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(num = sum(numerator))

arctic_mtc_den <- arctic_mtc %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(den = sum(relative_abundance))

arctic_mtc_final <- cbind(arctic_mtc_num$num,arctic_mtc_den$den)
arctic_mtc_final <- as.data.frame(arctic_mtc_final)
names(arctic_mtc_final) <- c("numerator", "denominator")

arctic_mtc_final <- arctic_mtc_final %>%
  mutate(final = numerator/denominator)

years = c(1994:2020)
arctic_mtc_value <- as_tibble(arctic_mtc_final$final)

final_mtc <- cbind(years,arctic_mtc_value)
names(final_mtc) <- c("Year", "MTC")

# Simple linear regression of trawl survey MTC and Year
#arctic MTC lm and figure
final_mtc$Year <- as.numeric(as.character(final_mtc$Year))
arctic_slope <- lm(MTC ~ Year, data=final_mtc)
summary(arctic_slope) # slope = 0.08

# for figure
lm.fitted.1 = fitted(arctic_slope)
lm.1.model = data.frame(Year = final_mtc$Year, MTC = lm.fitted.1)

# Adding oceanographic indicators to trawl survey data (1994-2020)
final_mtc <- cbind(final_mtc, ssta_trawl[45:71,2], oceano[45:71,2:4])
names(final_mtc) <- c("Year", "MTC", "SSTA", "AMO", "NAO", "AO")

matrix_1 <- rcorr( as.matrix( final_mtc[,c("MTC", "SSTA", "AMO", "NAO", "AO")], type = "pearson" ) )
corrplot( matrix_1$r, type = "lower", tl.col = "black", method = "number", title = "Research MTC", 
          mar = c( 0, 0, 1, 0 ), p.mat = matrix_1$P, sig.level = 0.05) 
# NAO & AO collinear, removing AO

arctic_mtc_remove <- final_mtc[,c(1:5)]

# Multiple linear regression of survey MTC on SSTA, NAO and AMO
MTC_multi <- lm(MTC ~ SSTA+NAO+AMO, data = arctic_mtc_remove) #note: R uses Type III SS as default
summary(MTC_multi)

#Model evaluation
#1)
residualPlots(MTC_multi) #AMO curvilinear

#2) Testing non-constant variance
ncvTest(MTC_multi) # p=0.006, non-constant variance detected

#3) Shapiro-Wilkes test
shapiro.test(residuals(MTC_multi))

#4) Variance inflation factors
vif(MTC_multi)

#5) Outlier test
outlierTest(MTC_multi)
outl<-as.numeric(names(which(outlierTest(MTC_multi)$bonf.p<0.05)))
outl

# All assumptions met, except non-constant variance (AMO)
# Using white correction for non-constant variance
Anova(MTC_multi, white.adjust=TRUE)

# Principal component analysis (singular value decomposition, SVD), with IMR MTC
# and all oceanographic variables (centred)

PCA_mtc <- final_mtc

mtc.pca <- PCA(PCA_mtc, scale.unit = TRUE, ncp=6, graph=TRUE)              
print(mtc.pca)
eig.val <- get_eigenvalue(mtc.pca)
eig.val

#scree plot to visually inspect PC's eigenvalues
fviz_eig(mtc.pca, addlabels = TRUE, ylim = c(0,60))

var <- get_pca_var(mtc.pca)
var
# access components
# Coordinates
head(var$coord)
# Cos2: quality on the factor map
head(var$cos2)
# Contributions to the principal components
head(var$contrib)

# plot variables
fviz_pca_var(mtc.pca, col.var="black", label = "var")

# extract pc scores for first two component and add to dat dataframe

PCA_mtc$pc1 = mtc.pca$ind$coord[, 1] # indexing the first carctic
PCA_mtc$pc2 = mtc.pca$ind$coord[, 2]  # indexing the second column

#We also need to extract the data for the variable contributions to each of the pc axes.
pca.vars <- mtc.pca$var$coord %>% data.frame
pca.vars$vars <- rownames(pca.vars)
pca.vars.m <- melt(pca.vars, id.vars = "vars")

Supp_Fig_3b <-  ggplot() + geom_path(data = circ,aes(x,y), lty = 2, color = "grey", alpha = 0.7) +
  geom_hline(yintercept = 0, lty = 2, color = "grey", alpha = 0.9) +
  geom_vline(xintercept = 0, lty = 2, color = "grey", alpha = 0.9) +
  geom_segment(data = pca.vars, aes(x = 0, xend = Dim.1, y = 0, yend = Dim.2),
               arrow = arrow(length = unit(0.025, "npc"), type = "open"), lwd = 1) +
  geom_text(data = pca.vars, aes(x = Dim.1*1.15, y =  Dim.2*1.15,
                                 label = c("Year","MTC","SSTA","AMO","NAO","AO")),check_overlap = F,size = 3) +
  xlab("PC 1") + 
  ylab("PC2") +
  coord_equal() +
  theme_minimal() +
  theme(panel.grid = element_blank(), 
        panel.border = element_rect(fill= "transparent"))

Supp_Fig_3b

# Combining fisheries PCA with survey PCA
Supp_Figure_3 = ggarrange(Supp_Fig_3a, Supp_Fig_3b, align = c("v"), ncol = 2, nrow=1,labels = c("a Fisheries  catch", "b Research data "))

Supp_Figure_3


# Plot of research MTC with SSTA (second axis)
Fig_3b = ggplot(data=final_mtc, aes(x=Year)) +
  geom_point(aes(y=MTC), cex=2.5, col="red") +
  geom_path(aes(y=MTC), cex=1.5, col="red") +
  geom_bar(aes(y=SSTA*10), stat="identity", size=.25, color="black", alpha=.4) +
  scale_y_continuous(breaks = seq(0,10,5),
                     name= "MTC (°C)",
                     sec.axis = sec_axis(~./10, name = "SSTA (°C)", breaks = seq(0,1,0.5))) +
  theme_classic() +
  ylab("MTC (°C)") +
  xlab("Year") +
  scale_x_continuous(breaks = seq(1950,2020,10), limits = c(1950,2020)) +
  theme(axis.text.x = element_text(size=24),
        axis.text.y = element_text(size=24),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        plot.margin = margin(0, 0.5, 0, 0.2,"cm")) +
  geom_line(data=lm.1.model, aes(x= Year, y= MTC), cex=1.3, col="black")

Fig_3b

# Investigating the influence of individual species on the MTC trend, 
# through their slope of abundance and maximum abundance value

# Changes in slope of recorded species
require(data.table)
dt <- data.table(total_arctic)
dt <- na.omit(dt)

slopes <- dt[,list(slope=lm(log_abundance~Year)$coef),by=scientific_name]

dat1 <- total_arctic

get.coef <- function(dat1) lm(log_abundance ~ Year, dat1)$coefficients

lm_results2 <- as.data.frame(ddply(dat1, .(scientific_name), get.coef))
sum(is.na(lm_results2))

max2 <- total_arctic %>%
  dplyr::group_by(scientific_name) %>%
  dplyr::summarise(mean = mean(relative_abundance))

str(max2)
max2$mean <- max2$mean %>% format(scientific=FALSE)

lm_max2 <- inner_join(lm_results2, max2, by = "scientific_name")

#include temp prefs
lm_max2 <- inner_join(lm_max2, temp_arctic, by = "scientific_name")
lm_max2 <- lm_max2 %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  )) %>%
  mutate(slope_change = case_when(
    Year > 0 ~ "Positive",
    Year < 0 ~ "Negative"
  ))

# Removing Norway pout and haddock, re-calculating MTC and trend

arctic_rerun <- droplevels(total_arctic[!total_arctic$scientific_name == 'Trisopterus esmarkii',])
arctic_rerun <- droplevels(arctic_rerun[!arctic_rerun$scientific_name == 'Melanogrammus aeglefinus',])
str(arctic_rerun)

arctic_rerun <- inner_join(arctic_rerun, temp_arctic, by="scientific_name")
arctic_rerun$scientific_name <- as.factor( paste0( as.factor( arctic_rerun$scientific_name )))
summary(arctic_rerun) #no NAs
str(arctic_rerun)

# 'Remove' MTC
arctic_rerun_temp <- arctic_rerun %>%
  dplyr::group_by(Year) %>%
  dplyr::mutate(numerator = relative_abundance*mean_temp)

arctic_rerun_num <- arctic_rerun_temp %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(num = sum(numerator))

arctic_rerun_den <- arctic_rerun %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(den = sum(relative_abundance))

arctic_rerun_numer <- as_tibble(arctic_rerun_num$num)
arctic_rerun_denom <- as_tibble(arctic_rerun_den$den)

arctic_rerun_final <- cbind(arctic_rerun_numer,arctic_rerun_denom)
names(arctic_rerun_final) <- c("numerator", "denominator")

arctic_rerun_final <- arctic_rerun_final %>%
  mutate(final = numerator/denominator)

years <- as_tibble(unique(arctic_mtc$Year))
arctic_rerun_value <- as_tibble(arctic_rerun_final$final)

arctic_mtc_rerun <- cbind(years,arctic_rerun_value)
names(arctic_mtc_rerun) <- c("Year", "MTC")

arctic_mtc_rerun$Year <- as.numeric(as.character(arctic_mtc_rerun$Year))
str(arctic_mtc_rerun)

arctic_rerun_slope <- lm(MTC ~ Year, data=arctic_mtc_rerun)
summary(arctic_rerun_slope) # slope = 0.04


lm.fitted.2 = fitted(arctic_rerun_slope)
lm.2.model = data.frame(Year = arctic_mtc_rerun$Year, MTC = lm.fitted.2)

# creating polygon for Supp Fig 5
re_run_poly <- cbind(final_mtc$Year, final_mtc$MTC, arctic_mtc_rerun$MTC)
re_run_poly <- as.data.frame(re_run_poly)
names(re_run_poly) <- c("Year", "MTC_with", "MTC_without")

Supp_Fig_5a = ggplot(data=re_run_poly, aes(x=Year, y=MTC_with)) +
  geom_line(cex=0.85, col="firebrick") +
  theme_classic() +
  geom_line(data=lm.1.model, aes(x=Year, y=MTC), col="firebrick", cex=0.85) +
  geom_line(data=lm.2.model, aes(x=Year, y=MTC), cex=0.85) +
  ylab("MTC (°C)") +
  scale_x_continuous(breaks=seq(1995,2020, by=5), limits = c(1994, 2021)) +
  scale_y_continuous(breaks = seq(1, 8, by = 1)) +
  theme(axis.text.x = element_text(size=26),
        axis.text.y = element_text(size=24),
        axis.title.x = element_blank(),
        axis.title.y = element_text(size=18)) +
  geom_line(data=re_run_poly,aes(x=Year,y= MTC_without),cex=0.85, linetype = "longdash") + 
  geom_ribbon(data = re_run_poly, aes(x=Year, ymin = MTC_without, ymax = MTC_with),
              color = "grey30", alpha = 0.05) +
  annotate("text", x = 2015, y = 6.4, size = 5.5, label = "Full MTC",
           col="firebrick") +
  annotate("text", x = 2015, y = 3.75, size = 5.5, label = "MTC without 2 spp.") +
  annotate("text", x = 1994, y = 7, size = 7, label = "a", fontface = "plain") +
  theme(legend.position = "none") 

Supp_Fig_5a

#Norway pout and haddock abundance throughout study area and period

# Norway pout image
norway_pout = total_arctic %>% filter(scientific_name == "Trisopterus esmarkii") %>% mutate(fig_abund = relative_abundance * 0.001)

haddock = total_arctic %>% filter(scientific_name == "Melanogrammus aeglefinus") %>% mutate(fig_abund = relative_abundance * 0.001)

Supp_Fig_5b = ggplot(data=norway_pout, aes(x=Year, y=fig_abund)) +
  geom_path(cex=0.85, col='red4') +
  geom_path(data=haddock, aes(x=Year, y=fig_abund), linetype = 'dashed', col='red1', cex=0.85) +
  theme_classic() +
  scale_x_continuous(breaks=seq(1995,2020, by=5), limits = c(1994, 2021)) +
  scale_y_continuous(breaks = seq(0, 6000, by = 1000)) +
  ylab("Abundance (# of individuals × 1000)") +
  theme(axis.text.x = element_text(size=26),
        axis.text.y = element_text(size=22),
        axis.title.x = element_blank(),
        axis.title.y = element_text(size=18)) +
  annotate("text", x = 2017.25, y = 4600, size = 5.5,
           label = "Trisopterus esmarkii",
           fontface = "italic", col = 'red4') +
  annotate("text", x = 2000, y = 4600, size = 5.5,
           label = "Melanogrammus",
           fontface = "italic", col = 'red1') +
  annotate("text", x = 2000, y = 4300, size = 5.5,
           label = "aeglefinus",
           fontface = "italic", col = 'red1') + 
  annotate("text", x = 1994, y = 6000, size = 7, label = "b", fontface = "plain")

Supp_Fig_5b





# Removing cold water species, Polar cod
remove <- c("Boreogadus saida")

arctic_rerun <- total_arctic %>% filter(!scientific_name %in% remove)

arctic_rerun <- inner_join(arctic_rerun, temp_arctic, by="scientific_name")
arctic_rerun$scientific_name <- as.factor( paste0( as.factor( arctic_rerun$scientific_name )))
summary(arctic_rerun) #no NAs
str(arctic_rerun)

# 'Remove' MTC
arctic_rerun_temp <- arctic_rerun %>%
  dplyr::group_by(Year) %>%
  dplyr::mutate(numerator = relative_abundance*mean_temp)

arctic_rerun_num <- arctic_rerun_temp %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(num = sum(numerator))

arctic_rerun_den <- arctic_rerun %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(den = sum(relative_abundance))

arctic_rerun_numer <- as_tibble(arctic_rerun_num$num)
arctic_rerun_denom <- as_tibble(arctic_rerun_den$den)

arctic_rerun_final <- cbind(arctic_rerun_numer,arctic_rerun_denom)
names(arctic_rerun_final) <- c("numerator", "denominator")

arctic_rerun_final <- arctic_rerun_final %>%
  mutate(final = numerator/denominator)

years <- as_tibble(unique(arctic_mtc$Year))
arctic_rerun_value <- as_tibble(arctic_rerun_final$final)

arctic_mtc_rerun <- cbind(years,arctic_rerun_value)
names(arctic_mtc_rerun) <- c("Year", "MTC")

arctic_mtc_rerun$Year <- as.numeric(as.character(arctic_mtc_rerun$Year))
str(arctic_mtc_rerun)

arctic_rerun_slope <- lm(MTC ~ Year, data=arctic_mtc_rerun)
summary(arctic_rerun_slope)

lm.fitted.3 = fitted(arctic_rerun_slope)
lm.3.model = data.frame(Year = arctic_mtc_rerun$Year, MTC = lm.fitted.3)

re_run_poly_cold <- cbind(final_mtc$Year, final_mtc$MTC, arctic_mtc_rerun$MTC)
re_run_poly_cold <- as.data.frame(re_run_poly_cold)
names(re_run_poly_cold) <- c("Year", "MTC_with", "MTC_without")

# Polar cod
polar_cod = total_arctic %>% filter(scientific_name == "Boreogadus saida") %>% mutate(fig_abund = relative_abundance * 0.001)

Supp_Fig_5c = ggplot(data=re_run_poly_cold, aes(x=Year, y=MTC_with)) +
  geom_line(cex=0.85, linetype = "longdash") +
  theme_classic() +
  geom_line(data=lm.1.model, aes(x=Year, y=MTC), cex=0.85) +
  geom_line(data=lm.3.model, aes(x=Year, y=MTC), col = "darkblue", cex=0.85) +
  ylab("MTC (°C)") +
  scale_x_continuous(breaks=seq(1995,2020, by=5), limits = c(1994, 2021)) +
  scale_y_continuous(breaks = seq(1, 8, by = 1)) +
  theme(axis.text.x = element_text(size=26),
        axis.text.y = element_text(size=24),
        axis.title.x = element_blank(),
        axis.title.y = element_text(size=18)) +
  geom_line(data=re_run_poly_cold,aes(x=Year,y= MTC_without),cex=0.85, col = "darkblue") + 
  geom_ribbon(data = re_run_poly_cold, aes(x=Year, ymin = MTC_without, ymax = MTC_with),
              color = "grey30", alpha = 0.05) +
  annotate("text", x = 2002.75, y = 3.75, size = 5.5, label = "Full MTC") +
  annotate("text", x = 2001.5, y = 6.75, size = 5.5, label = "MTC without", col = "darkblue") +
  annotate("text", x = 2001.5, y = 6.5, size = 5.5, label = "polar cod", col = "darkblue") +
  annotate("text", x = 1994, y = 7, size = 7, label = "c", fontface = "plain") +
  theme(legend.position = "none")

Supp_Fig_5c

Supp_Fig_5d = ggplot(data=polar_cod, aes(x=Year, y=fig_abund)) +
  geom_path(cex=0.85, col='mediumblue') +
  theme_classic() +
  scale_x_continuous(breaks=seq(1995,2020, by=5), limits = c(1994, 2021)) +
  scale_y_continuous(breaks = seq(0, 10000, by = 2000)) +
  ylab("Abundance (# of individuals × 1000)") +
  theme(axis.text.x = element_text(size=26),
        axis.text.y = element_text(size=20),
        axis.title.x = element_blank(),
        axis.title.y = element_text(size=18)) +
  annotate("text", x = 2017.55, y = 7500, size = 5.5,
           label = "Boreogadus saida",
           fontface = "italic", col = 'mediumblue') +
  annotate("text", x = 1994, y = 10000, size = 7,
           label = "d", fontface = "plain") +
  theme(plot.margin = margin(0, 0.5, 0, 0,"cm"))

Supp_Fig_5d

Supp_Fig_5 = ggarrange(
  Supp_Fig_5a,
  Supp_Fig_5b,
  Supp_Fig_5c,
  Supp_Fig_5d,
  align = c("h"), 
  ncol = 2,
  nrow=2)

Supp_Fig_5


# ANCOVA between research and fisheries MTC trends (after fisheries breakpoint, 1978)
SAU_Norway_mtc <- SAU_Norway_mtc %>%
  mutate(group = "SAU")

IMR_mtc <- final_mtc %>%
  mutate(group = "IMR")

MTC_ANCOVA <- rbind(SAU_Norway_mtc[29:69,c(1,2,7)], IMR_mtc[,c(1,2,7)])

# ANCOVA
MTC_ANCOVA %>% anova_test(MTC ~ group*Year) #Heterogeneity of regression slope,
# interaction term NOT significant

#Checking normality of residuals
model <- lm(MTC ~ Year + group, data = MTC_ANCOVA)
# Inspect the model diagnostic metrics
model.metrics <- augment(model) %>%
  select(-.hat, -.sigma, -.fitted) # Remove details
head(model.metrics)

# Assess normality of residuals using Shapiro Wilk test
shapiro_test(model.metrics$.resid)
#The Shapiro Wilk test was not significant (p > 0.05), so we can assume normality of residuals

# Homogeneity of variances
# ANCOVA assumes that the variance of the residuals is equal for all groups.
# This can be checked using Levene’s test:
model.metrics %>% levene_test(.resid ~ group)
# The Levene’s test was not significant (p > 0.05),
# so we can assume homogeneity of the residual variances for all groups.

#Outliers
model.metrics %>% 
  filter(abs(.std.resid) > 3) %>%
  as.data.frame() #MTC of 1.70 in IMR 1998 is an outlier, but we retain it

#Computation
res.aov <- MTC_ANCOVA %>% anova_test(MTC ~ Year + group)
get_anova_table(res.aov)

# ANCOVA post-hoc test, pairwise comparisons
pwc <- MTC_ANCOVA %>% 
  emmeans_test(
    MTC ~ group, covariate = Year,
    p.adjust.method = "bonferroni"
  )
pwc
get_emmeans(pwc)


# ANCOVA between research and fisheries MTC trends
# with temporal overlap (1994-2020)

# Fisheries linear regression, MTC ~ Year from 1994-2018
sau_restrict <- lm(MTC ~ Year, data=SAU_Norway_mtc[45:69,])
summary(sau_restrict)

# ANCOVA restricted to fisheries data, 1994-2018
MTC_ANCOVA_rest <- rbind(SAU_Norway_mtc[45:69,c(1,2,7)], IMR_mtc[,c(1,2,7)])

# ANCOVA
MTC_ANCOVA_rest %>% anova_test(MTC ~ group*Year) #Heterogeneity of regression slope,
# interaction term significant


Fig_3c = ggplot(data=MTC_ANCOVA, aes(x=Year, y=MTC, colour=group)) + 
  geom_point() +
  geom_smooth(method='lm', formula= y~x, se=F, size=1.3) +
  geom_smooth(data=SAU_Norway_mtc[45:69,], aes(x=Year, y=MTC), method = 'lm', formula = y~x, se=F, col='black', size=1.3) +
  scale_x_continuous(breaks = seq(1950,2020,10), limits = c(1950,2020)) +
  scale_y_continuous(breaks = seq(0,10,5), limits = c(0,10)) +
  ylab("MTC °C") +
  xlab("Year") +
  scale_color_discrete(name = 'MTC', labels = c("Survey data", "Fisheries data")) +
  theme_classic() +
  theme(axis.text.x = element_text(size=24),
        axis.text.y = element_text(size=24),
        axis.title.x = element_blank(),
        axis.title.y = element_blank()) +
  theme(legend.position = "none",
        plot.margin = margin(0, 1.8, 0, 0.2,"cm")) +
  annotate(geom="text", x=1969, y=5.2, label="Fisheries data", size=6,
           col= "#00BFC4") +
  annotate(geom="text", x=1969, y=4.2, label="1978-2018", size=6,
           col= "#00BFC4") +
  annotate(geom="text", x=2013, y=3.3, label="Research data", size=6,
           col = "#F8766D") +
  annotate(geom="text", x=2013, y=2.4, label="1994-2020", size=6,
           col = "#F8766D") +
  annotate(geom="text", x=2010, y=9.2, label="Fisheries data", size=6) +
  annotate(geom="text", x=2010, y=8.2, label="1994-2018", size=6) 

# Figure 3
Fig_3 = ggarrange(Fig_3a,Fig_3b,Fig_3c, align = c("h"), ncol = 1, nrow=3, labels = c("a Fisheries data", "b Research data", "c MTC slopes"), font.label = list(size = 20, face = "plain"), hjust=-0.4)

Fig_3 = annotate_figure(Fig_3,
                           left = text_grob("MTC (°C)", size=26,  rot = 90),
                           right = text_grob("SSTA (°C)", size=26, rot = -90, hjust = 1.5)) +
  theme(plot.margin = margin(0, 0.5, 0, 0.5,"cm"))


Fig_3

# Investigating the ratio of "warm" to "cold" species, plus abundance (catch)
# of warm and cold species, based on mean temperature preference of all unique
# species included in both fisheries and survey data (n=172)

# Gather temperature preferences of all unique species
FULL_temp <- rbind(SAU_temp, temp_arctic)

FULL_temp <- FULL_temp[!duplicated(FULL_temp), ]
FULL_temp <- FULL_temp %>% distinct() #172 species

mean(FULL_temp$mean_temp) #6.29 degrees C, mean temperature preference


# IMR trawl survey data, ratio of warm (> 6.29 C) to cold (< 6.29 C)
ratio <- arctic_mtc_temp[,c(1,2,5)]

ratio <- ratio %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  ))

ratio$preference <- as.factor( paste0( as.factor( ratio$preference )))
str(ratio)

Warm <- ratio %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(n_Warm = sum(preference=="Warm"))

Cold <- ratio %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(n_Cold=sum(preference=="Cold"))

n_Warm <- as_tibble(Warm$n_Warm)
n_Cold <- as_tibble(Cold$n_Cold)

years <- seq(1994,2020)

temp_ratio <- cbind(years,n_Cold,n_Warm)
names(temp_ratio) <- c("year", "Cold", "Warm")

final_ratio <- temp_ratio %>%
  mutate(ratio = Warm/Cold)

final_ratio$year <- as.numeric(as.character(final_ratio$year))
final_ratio$ratio <- as.numeric(as.character(final_ratio$ratio))
str(final_ratio)


# Abundance by thermal preference
thermal_abundance <- arctic_mtc_temp %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  ))

str(thermal_abundance)
thermal_abundance$preference <- as.factor( paste0( as.factor( thermal_abundance$preference )))

cold_total <- thermal_abundance %>% filter(preference == "Cold")
warm_total <- thermal_abundance %>% filter(preference == "Warm")

total <- thermal_abundance %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(total = sum(relative_abundance))

thermal <- thermal_abundance %>%  
  dplyr::group_by(Year, preference) %>%
  dplyr::summarise(abundance = sum(relative_abundance))

thermal <- left_join(thermal, total)
thermal <- thermal %>%
  mutate(ratio = abundance/total)

thermal$preference <- as.factor( paste0( as.factor( thermal$preference )))
thermal$Year <- as.numeric(as.character(thermal$Year))
str(thermal)

pref_colours <- c(Cold = "steelblue4", Warm = "firebrick1")
thermal$preference <- factor(thermal$preference, levels = c("Warm", "Cold"))
legend_title <- c("Thermal preference")


# Paired t-test to compare the mean annual relative abundance
# of warm- and cold-water species
thermal_t <- arctic_mtc_temp %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  ))

thermal_t_test = thermal_t %>%
  dplyr::group_by(Year, preference) %>%
  dplyr::summarise(mean = mean(relative_abundance))

thermal_t_test$preference <- as.factor( paste0( as.factor( thermal_t_test$preference )))

t_test <- thermal_t_test %>% group_by(preference) %>% mutate(id = row_number()) %>% ungroup() %>% pivot_wider(id_cols = id, names_from = preference, values_from = mean) %>% select(-id) %>%
  mutate(years = 1994:2020)

t.test(t_test$Warm, t_test$Cold, paired=TRUE, alternative="two.sided")
mean(t_test$Warm)
mean(t_test$Cold)


# Sea Around Us catch data, ratio of warm (> 6.29 C) to cold (< 6.29 C)
sau_ratio <- SAU_mtc_temp[,c(1,2,5)]

sau_ratio <- sau_ratio %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  ))

sau_ratio$preference <- as.factor( paste0( as.factor( sau_ratio$preference )))
str(sau_ratio)

sau_Warm <- sau_ratio %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(n_Warm = sum(preference=="Warm"))

sau_Cold <- sau_ratio %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(n_Cold=sum(preference=="Cold"))

sau_n_Warm <- as_tibble(sau_Warm$n_Warm)
sau_n_Cold <- as_tibble(sau_Cold$n_Cold)


sau_temp_ratio <- cbind(SAU_years,sau_n_Cold,sau_n_Warm)
names(sau_temp_ratio) <- c("year", "Cold", "Warm")

sau_final_ratio <- sau_temp_ratio %>%
  mutate(ratio = Warm/Cold)

sau_final_ratio$year <- as.numeric(as.character(sau_final_ratio$year))
sau_final_ratio$ratio <- as.numeric(as.character(sau_final_ratio$ratio))
str(sau_final_ratio)
summary(sau_final_ratio$ratio)


# Catch by thermal preference
sau_thermal_abundance <- SAU_mtc_temp %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  ))

str(sau_thermal_abundance)
sau_thermal_abundance$preference <- as.factor( paste0( as.factor( sau_thermal_abundance$preference )))

sau_thermal <- sau_thermal_abundance %>%  
  dplyr::group_by(Year, preference) %>%
  dplyr::summarise(abundance = sum(catch))

sau_thermal$preference <- as.factor( paste0( as.factor( sau_thermal$preference )))
sau_thermal$Year <- as.numeric(as.character(sau_thermal$Year))
str(sau_thermal)

pref_colours <- c(Cold = "steelblue4", Warm = "firebrick1")
sau_thermal$preference <- factor(sau_thermal$preference, levels = c("Warm", "Cold"))
legend_title <- c("Thermal preference")

sau_thermal <- sau_thermal %>%
  mutate(catch = abundance*0.000001)

# Paired t-test to compare the mean annual catch
# of warm- and cold-water species
thermal_c = SAU_mtc_temp %>%
  mutate(preference = case_when(
    mean_temp > 6.290116 ~ "Warm",
    mean_temp < 6.290116 ~ "Cold"
  ))

thermal_c_test = thermal_c %>%
  dplyr::group_by(Year, preference) %>%
  dplyr::summarise(mean = mean(catch))

thermal_c_test$preference <- as.factor( paste0( as.factor( thermal_c_test$preference )))

t_test <- thermal_c_test %>% group_by(preference) %>% mutate(id = row_number()) %>% ungroup() %>% pivot_wider(id_cols = id, names_from = preference, values_from = mean) %>% select(-id) %>%
  mutate(years = 1950:2018)

t.test(t_test$Warm, t_test$Cold, paired=TRUE, alternative="two.sided")
mean(t_test$Warm)
mean(t_test$Cold)

thermal_warm <- thermal %>% filter(preference == "Warm") %>% mutate(fig_abun = abundance * 0.0025)
thermal_cold <- thermal %>% filter(preference == "Cold") %>% mutate(fig_abun = abundance * 0.0025)

sau_total <- sau_thermal %>%
  dplyr::group_by(Year) %>%
  dplyr::summarise(total = sum(abundance))

sau_thermal <- left_join(sau_thermal, sau_total)
sau_thermal <- sau_thermal %>%
  mutate(ratio = abundance/total)

sau_thermal_warm <- sau_thermal %>% filter(preference == "Warm")
sau_thermal_cold <- sau_thermal %>% filter(preference == "Cold") %>%
  mutate(fig_ratio = 1-ratio)

sau_final_ratio <- sau_final_ratio %>% mutate(cold_fig = Cold/60) %>% mutate(warm_fig = Warm/60)

# added second axis and trend line
Fig_4a <- ggplot() +
  geom_ribbon(data = sau_thermal_warm, aes(x=Year, ymin=0, ymax=ratio), fill = "firebrick1", alpha = 0.4) +
  geom_ribbon(data = sau_thermal_cold, aes(x=Year, ymin=fig_ratio, ymax=1), fill = "steelblue4", alpha = 0.4) +
  theme_classic() +
  labs(y = "Proportion of fisheries catch", x = "Year") +
  scale_x_continuous(breaks = seq(1950, 2020, by = 10)) +
  scale_y_continuous(
    sec.axis = sec_axis(~.*60, name = expression(paste("# of species recorded")))
  ) +
  geom_line(data=sau_final_ratio, aes(x=year, y=cold_fig), size=0.9, col = "steelblue4") +
  geom_line(data=sau_final_ratio, aes(x=year, y=warm_fig), size=0.9, col = "firebrick1") +
  theme(legend.position="top") +
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_blank(),
        axis.text.x = element_text(size = 18),
        axis.text.y = element_text(size = 18),
        axis.title.y.right = element_text(size= 14))

Fig_4a

#imr spp ratio
final_ratio <- final_ratio %>% mutate(cold_fig = Cold/60) %>% mutate(warm_fig = Warm/60)

Fig_4b <- ggplot() +
  geom_ribbon(data = thermal_warm, aes(x=Year, ymin=0, ymax=ratio), fill = "firebrick1", alpha = 0.4) +
  geom_ribbon(data = thermal_warm, aes(x=Year, ymin=ratio, ymax=1), fill = "steelblue4", alpha = 0.4) +
  theme_classic() +
  labs(y = "Proportion of research data (total individuals)", x = "Year") +
  scale_x_continuous(breaks = seq(1950, 2020, by = 10), limits = c(1950,2020)) +
  scale_y_continuous(
    sec.axis = sec_axis(~.*60, name = expression(paste("# of species recorded")))
  ) +
  geom_line(data=final_ratio, aes(x=year, y=cold_fig), size=0.9, col = "steelblue4") +
  geom_line(data=final_ratio, aes(x=year, y=warm_fig), size=0.9, col = "firebrick1") +
  theme(legend.position="top") +
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_blank(),
        axis.text.x = element_text(size = 18),
        axis.text.y = element_text(size = 18),
        axis.title.y.right = element_text(size= 14)) +
  annotate("text", x = 1970, y = 0.9, size = 4.5, label = "Cold-water species (< 6.3 °C)",
           col="steelblue4") +
  annotate("text", x = 1970, y = 0.83, size = 4.5, label = "Warm-water species (> 6.3 °C)",
           col="firebrick1")


Fig_4 = ggarrange(Fig_4a, Fig_4b,
                     align = c("h"),                   
                     ncol = 1,
                     nrow=2,
                     labels = c("a Fisheries data", "b Research data"),
                     font.label = list(size = 14, face = "plain"),
                     hjust=-0.8)

Fig_4
